"""This __init__ file will be called once triggered is generated."""
import time

import azure.functions as func

from ..SharedCode.logger import applogger
from .bitsight_findings_summary import BitSightFindingsSummary


def main(mytimer: func.TimerRequest) -> None:
    """Start the execution.

    Args:
        mytimer (func.TimerRequest): timer trigger
    """
    start_time = time.time()
    applogger.info("BitSight: Findings Summary: Start processing...")
    breaches_obj = BitSightFindingsSummary(start_time)
    breaches_obj.get_findings_summary_data_into_sentinel()
    end = time.time()
    applogger.info(
        "BitSight: time taken for data ingestion is {} sec".format(int(end - start_time))
    )
    applogger.info("BitSight: Findings_summary_details: execution completed.")
    if mytimer.past_due:
        applogger.info("The timer is past due!")
